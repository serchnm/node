'use strict'
const service = require('../service/service');
//const s3 = require('../config/s3.config');
  
module.exports = {	
	doUploadNative: async (req, res) => {
		let response;

		await service.doUploadNative(req)
		.then(result => {
			response = result
		})
		.catch(err => {
			console.log(err);
		});
		return res.status(200).send(response);		
	},
	doUpload : async (req, res) => {
		let response;

		await service.doUpload(req)
		.then(result => {
			response = result
		})
		.catch(err => {
			console.log(err);
		});
		return res.status(200).send(response);		
	},
	doDownload: async (req, res) => { 
		await service.doDownload(req, res)
		return res;
	}
}

// let response;

		// await service.doDownload(req)
		// .then(result => {
		// 	response = result
		// })
		// .catch(err => {
		// 	console.log(err);
		// });
		// return res.status(200).send(response);