const env = {
	AWS_ACCESS_KEY: 'AKIAR6E4AHOITXJP77KA', // change to yours
	AWS_SECRET_ACCESS_KEY: 'rmarncP64bnof+67P51pQ6f44TGx2EdHWwt3oHcV', // change to yours
	REGION : 'us-east-2', // change to yours
	Bucket: 'nomcalifornia' // change to yours
};

module.exports = env;