'use strict'
const serviceEsterno = require('../serviceExterno/uploadS3');

module.exports = {
    doUploadNative: async (req) => {
        let response = {Message: 'Ok'};

        await serviceEsterno.upload(req)
        .then(result => {
            response = {
                VideoId: req.params.videoId,
                Path: result
            };
        })
        .catch(err => {
            console.log('err jojo');
            console.log(err);
        });
        return response;
    },
    doUpload: async (req) => {
        let response = {Message: 'Ok'}; 

        await serviceEsterno.uploadMulterS3(req)
        .then(result => { 
             response = {
                VideoId: req.params.videoId,
                Path: result.file.key.split('.')[0]
            };
        })
        .catch(err => {
            console.log('err jojo');
            console.log(err);
        });
        return response;
    },
    doDownload: async (req, res) => {
        let path = `${req.params.path}/${req.params.fileName}`;
        await serviceEsterno.download(path, res); 
        return res; 
    }
}