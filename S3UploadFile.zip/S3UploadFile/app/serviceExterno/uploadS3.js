'use strict'
const fs = require('fs');
const AWS = require('aws-sdk');
const multer = require('multer');
const multerS3 = require('multer-s3')
const s3 = new AWS.S3({ accessKeyId: "AKIAR6E4AHOITXJP77KA", secretAccessKey: "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" });
 
const uploadMulterS3 = multer({
  storage: multerS3({
    s3: s3,
    acl: 'public-read',
    bucket: 'nomnomdevtest',
    metadata: (req, file, cb) => {
      cb(null, {fieldName: file.fieldname})
    },
    key: (req, file, cb) => {
      const path = {
        Video: `${req.params.videoId}/video-${Date.now()}`
      }

      cb(null, `uploads/${path.Video}.mp4`);
    }
  })
}).single('video');

 
var storage = multer.memoryStorage()
var upload = multer({storage: storage}).single('video');
const s3Config = require('../config/s3.config');
 
let uploadVideo = async (req) => {
  return new Promise(async function (resolve, reject) {
      await upload(req, null, (err,) => {
        if(err){ reject(err); } 
        else { resolve(req); }
      });
    });
}

module.exports = {
    uploadMulterS3: async (req) => {
        return new Promise(async function (resolve, reject) {
            await uploadMulterS3(req, null, function(err, result){
                if(err){
                    reject(err);
                } else {
                    resolve(req);
                }
            })
        });
    },
    upload: async (req) => {
      let file;
      await uploadVideo(req).then(result => { file = result.file; })
      .catch(err => { 
        console.log(err);
      });   

      const s3Client = s3Config.s3Client;
      const params = s3Config.uploadParams;
      const path = {
        Video: `${req.params.videoId}/video-${Date.now()}`
      }

      params.Key = `uploads/${path.Video}.mp4`;
      params.Body = file.buffer;
      
      return new Promise(async function (resolve, reject) {
        await s3Client.upload(params, (err, data) => {
          if(err){ reject(err); } 
          else { resolve(path); }
        });
      });
    },



    
    download: async(path, res) => {
      const s3Client = s3Config.s3Client;
      const params = s3Config.downloadParams;
      
      params.Key = `uploads/${path}.mp4`;
      
      s3Client.getObject(params)
        .createReadStream()
          .on('error', function(err){
            res.status(500).json({error:"Error -> " + err});
        }).pipe(res);
      }
}



        // console.log(req.params);
        // console.log(req.body);


        // s3.listBuckets({}, (err, data) => {
        //     if(err) {console.log(err);}
        //     console.log(data);
        // });

        // var parametros = { Bucket: 'nomnomdevtest' };
        // s3.listObjectsV2(parametros, (err, data) => {
        //     if(err) {console.log(err);}
        //      console.log(data);
        // })

        // var parametrosGetObject = {
        //     Bucket: 'nomnomdevtest',
        //     Key: 'videos/cat.mp4'
        // }
        // s3.getObject(parametrosGetObject, (err, data) => {
        //     if(err) {console.log(err);}
        //     console.log(data);    
        //     fs.writeFile("cat.mp4", data.Body, 'binary', (err) => {
        //         if(err) {console.log(err);}
        //         console.log('imagen grabada al disco');
        //     })
        // });
