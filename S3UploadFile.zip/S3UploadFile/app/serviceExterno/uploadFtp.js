// multer-ftp Upload

'use strict'

const multer = require('multer');
const FTPStorage = require('multer-ftp');
const FTP = require('ftp');
const fs = require('fs');
const path = require('path');

// const ffprobe = require('ffprobe');
// const ffprobeStatic = require('ffprobe-static');
// const logger = require('../../log/logger');

var ftp = new FTP();
ftp.connect({
    host: 'ftp.drivehq.com',
    user: '1993-jlaraujo',
    password: 'Arkus@123'
})

let uploadVideo = multer({
    storage: new FTPStorage({ 
        basepath: '/uploads',         
        connection: ftp,
        destination: function (req, file, options, callback) {
            var fileName = `${file.fieldname}-${Date.now()}.mp4`;
            callback(null, path.join(options.basepath, fileName))
        }
    })
}).single('video');

module.exports = {
    upload: async (req) => {
        return new Promise(async function (resolve, reject) {
            await uploadVideo(req, null, function(err, result) {
                if(err) {
                    reject(err);
                } else {
                    resolve(req);
                }
            })
        });
    }
};

//Uploads Videos a FTP
// await upload(req)
// .then(result => {
//     console.log(result.file)
//     console.log('termino de subir');
// }).catch(err => {
//     console.log(err);
//     console.log('trono asta aqeui');
// })
