'use strict'
let express = require('express');
let router = express.Router(); 
const awsWorker = require('../controllers/aws.controller.js'); 
 
router.post('/api/file/upload/native/:videoId', awsWorker.doUploadNative);
router.post('/api/file/upload/:videoId', awsWorker.doUpload);
router.get('/api/file/download/:path/:fileName', awsWorker.doDownload);
router.get('/api/test', function(req, res) {
    res.status(200).send({Message:"Success"})
});
 
module.exports = router; 
