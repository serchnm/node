'use strict'
const express = require('express');
const app = express();
 
let router = require('./app/routers/upload.router.js');
// app.use(express.urlencoded({ limit: '50mb', extended:true}));
// app.use(express.json({ limit : '50mb' }));

app.use(express.urlencoded({extended:false}));
app.use(express.json());
app.use('/', router);

// Create a Server

const port = process.env.PORT || 8001

const server = app.listen(port, function () {
 
  // let host = server.address().address
  // let port = server.address().port
 
  console.log("App listening at http://localhost:" +port); 
})